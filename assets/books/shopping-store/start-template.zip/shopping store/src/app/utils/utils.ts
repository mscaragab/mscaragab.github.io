import { Observable } from 'rxjs';

export class Utils {
  public static getObservable<T>(value: any, delay = false): Observable<T> {
    const observable = new Observable<T>((observer) => {
      if (delay) {
        setTimeout(() => {
          observer.next(value);
        }, 100);
      } else {
        observer.next(value);
      }
    });

    return observable;
  }

  public static limitWords(value: string, limit: number = 10) {
    if (value) {
      const items = value.split(' ');
      if (items.length > limit) return items.slice(0, limit).join(' ') + '...';
    }
    return value;
  }

  public static friendlyUrl(value: string) {
    if (value && value.length > 0)
      return value
        .replace(/[^a-z0-9]/gi, '-')
        .split('-')
        .filter((i) => i)
        .slice(0, 20)
        .join('-');
    return value;
  }
}
